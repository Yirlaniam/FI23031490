import java.util.ArrayList;

public class MyStackFloat implements MyStackInterface<Float> {

  private ArrayList<Float> myList = new ArrayList<Float>();

	public void push(Float item) {
		throw new UnsupportedOperationException("Unimplemented method 'push'");
	}

	public Float pop() {
		throw new UnsupportedOperationException("Unimplemented method 'pop'");
	}

	public Float peek() {
		throw new UnsupportedOperationException("Unimplemented method 'peek'");
	}

	public boolean empty() {
		throw new UnsupportedOperationException("Unimplemented method 'empty'");
	}

	public int size() {
		throw new UnsupportedOperationException("Unimplemented method 'size'");
	}
  
}
