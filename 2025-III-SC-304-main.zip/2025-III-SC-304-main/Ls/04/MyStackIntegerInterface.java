
public interface MyStackIntegerInterface {
  
  void push(int num);

  int pop();

  int peek();

  boolean empty();

  int size();
}
